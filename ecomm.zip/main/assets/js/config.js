var primary = localStorage.getItem("primary") || '#308e87';
var secondary = localStorage.getItem("secondary") || '#f39159';

window.AdmiroAdminConfig = {  
	// Theme Primary Color
	primary: primary,
	// theme secondary color
	secondary: secondary,
};

