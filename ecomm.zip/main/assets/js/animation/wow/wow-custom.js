wow = new WOW({
  animateClass: 'animated',
  offset: 100,
  callback: function (box) {},
});
wow.init();